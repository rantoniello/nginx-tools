#!/bin/sh

systemctl daemon-reload
systemctl enable prometheus-nginxlog-exporter